# Coursera_deep_learning
This something about deep learning on Coursera by Andrew Ng


## Notice

虽然作业我都上传了我的代码，但是请诚信编程，完全照着我的写，不会有进步的，独立完成，遇到难以解决的错误和难题时，适当参考我的解决方法。

尽管你会觉得看着我的代码也很简单，很好理解，就直接复制了，可是如果你独立完成的话，并不是想象的那么容易，也会很快的遗忘。

Please Honor Code！



# 第三周笔记
实现一个简单的3层全连接神经网络

## 正向传播

![](https://github.com/cryer/Coursera_deep_learning/raw/master/image/1.png)

## 反向传播

![](https://github.com/cryer/Coursera_deep_learning/raw/master/image/2.png)


## 隐藏层神经元数量和分类效果的关系

![](https://github.com/cryer/Coursera_deep_learning/raw/master/image/3.png)

![](https://github.com/cryer/Coursera_deep_learning/raw/master/image/4.png)



# 吴恩达深度学习第五专题第三周


## notice

Honor Code Please

## 关键Slide

![](https://github.com/cryer/Coursera_deep_learning/raw/master/sequence%20model/week3/image/41.png)

![](https://github.com/cryer/Coursera_deep_learning/raw/master/sequence%20model/week3/image/42.png)

![](https://github.com/cryer/Coursera_deep_learning/raw/master/sequence%20model/week3/image/43.png)

![](https://github.com/cryer/Coursera_deep_learning/raw/master/sequence%20model/week3/image/44.png)

![](https://github.com/cryer/Coursera_deep_learning/raw/master/sequence%20model/week3/image/45.png)

![](https://github.com/cryer/Coursera_deep_learning/raw/master/sequence%20model/week3/image/46.png)

![](https://github.com/cryer/Coursera_deep_learning/raw/master/sequence%20model/week3/image/47.png)

![](https://github.com/cryer/Coursera_deep_learning/raw/master/sequence%20model/week3/image/48.png)

![](https://github.com/cryer/Coursera_deep_learning/raw/master/sequence%20model/week3/image/49.png)

![](https://github.com/cryer/Coursera_deep_learning/raw/master/sequence%20model/week3/image/50.png)

![](https://github.com/cryer/Coursera_deep_learning/raw/master/sequence%20model/week3/image/51.png)

![](https://github.com/cryer/Coursera_deep_learning/raw/master/sequence%20model/week3/image/52.png)

![](https://github.com/cryer/Coursera_deep_learning/raw/master/sequence%20model/week3/image/53.png)

![](https://github.com/cryer/Coursera_deep_learning/raw/master/sequence%20model/week3/image/54.png)

![](https://github.com/cryer/Coursera_deep_learning/raw/master/sequence%20model/week3/image/55.png)

![](https://github.com/cryer/Coursera_deep_learning/raw/master/sequence%20model/week3/image/56.png)

![](https://github.com/cryer/Coursera_deep_learning/raw/master/sequence%20model/week3/image/57.png)

![](https://github.com/cryer/Coursera_deep_learning/raw/master/sequence%20model/week3/image/58.png)

![](https://github.com/cryer/Coursera_deep_learning/raw/master/sequence%20model/week3/image/59.png)

![](https://github.com/cryer/Coursera_deep_learning/raw/master/sequence%20model/week3/image/60.png)

![](https://github.com/cryer/Coursera_deep_learning/raw/master/sequence%20model/week3/image/61.png)

![](https://github.com/cryer/Coursera_deep_learning/raw/master/sequence%20model/week3/image/62.png)

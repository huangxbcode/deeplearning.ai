

# 创作爵士独奏曲

本周的第三次作业，很有趣，创作爵士独奏曲，本质上还是LSTM，但是音符和音乐数据的处理都已经给出，你自己还是处理简单的序列模型，
关于数据处理的代码我还没有看，毕竟很有意思，抽空可以研究一下。


关于训练数据可以自行下载一下。

<audio src="https://github.com/cryer/Coursera_deep_learning/tree/master/sequence%20model/week1/Improvise%20a%20Jazz%20Solo/my_music.midi" controls="controls">
</audio>

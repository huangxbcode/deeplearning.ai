

# 从头实现RNN

主要利用numpy一步一步从头实现RNN和LSTM,老规矩，贴出本周Ng的关键课程Slide。就不多讲解了，Ng的视频里说的很清楚了。

![](https://github.com/cryer/Coursera_deep_learning/raw/master/sequence%20model/week1/image/1.png)

![](https://github.com/cryer/Coursera_deep_learning/raw/master/sequence%20model/week1/image/2.png)

![](https://github.com/cryer/Coursera_deep_learning/raw/master/sequence%20model/week1/image/3.png)

![](https://github.com/cryer/Coursera_deep_learning/raw/master/sequence%20model/week1/image/4.png)

![](https://github.com/cryer/Coursera_deep_learning/raw/master/sequence%20model/week1/image/5.png)

![](https://github.com/cryer/Coursera_deep_learning/raw/master/sequence%20model/week1/image/6.png)

![](https://github.com/cryer/Coursera_deep_learning/raw/master/sequence%20model/week1/image/7.png)

![](https://github.com/cryer/Coursera_deep_learning/raw/master/sequence%20model/week1/image/8.png)

![](https://github.com/cryer/Coursera_deep_learning/raw/master/sequence%20model/week1/image/9.png)

![](https://github.com/cryer/Coursera_deep_learning/raw/master/sequence%20model/week1/image/10.png)

![](https://github.com/cryer/Coursera_deep_learning/raw/master/sequence%20model/week1/image/11.png)

![](https://github.com/cryer/Coursera_deep_learning/raw/master/sequence%20model/week1/image/12.png)

![](https://github.com/cryer/Coursera_deep_learning/raw/master/sequence%20model/week1/image/13.png)

![](https://github.com/cryer/Coursera_deep_learning/raw/master/sequence%20model/week1/image/14.png)

![](https://github.com/cryer/Coursera_deep_learning/raw/master/sequence%20model/week1/image/15.png)

![](https://github.com/cryer/Coursera_deep_learning/raw/master/sequence%20model/week1/image/16.png)





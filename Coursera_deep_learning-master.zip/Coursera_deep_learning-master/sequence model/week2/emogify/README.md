

# Emogify

很有意思的应用，根据描述语言，选出最符合语境的表情。

## 注意点

* Keras embeding层的输入格式
* embeding层如何导入预训练的权重，并且不更新
* 直接平均词向量方法的缺点
* LSTM等RNN的优势

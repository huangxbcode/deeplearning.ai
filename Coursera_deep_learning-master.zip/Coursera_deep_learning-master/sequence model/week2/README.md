

# 吴恩达深度学习第五专题第二周

## notice

请诚信编程，代码仅供交流参考

## 关键Slide

![](https://github.com/cryer/Coursera_deep_learning/raw/master/sequence%20model/week2/image/20.png)

![](https://github.com/cryer/Coursera_deep_learning/raw/master/sequence%20model/week2/image/21.png)

![](https://github.com/cryer/Coursera_deep_learning/raw/master/sequence%20model/week2/image/22.png)

![](https://github.com/cryer/Coursera_deep_learning/raw/master/sequence%20model/week2/image/23.png)

![](https://github.com/cryer/Coursera_deep_learning/raw/master/sequence%20model/week2/image/24.png)

![](https://github.com/cryer/Coursera_deep_learning/raw/master/sequence%20model/week2/image/25.png)

![](https://github.com/cryer/Coursera_deep_learning/raw/master/sequence%20model/week2/image/26.png)

![](https://github.com/cryer/Coursera_deep_learning/raw/master/sequence%20model/week2/image/27.png)

![](https://github.com/cryer/Coursera_deep_learning/raw/master/sequence%20model/week2/image/28.png)

![](https://github.com/cryer/Coursera_deep_learning/raw/master/sequence%20model/week2/image/29.png)

![](https://github.com/cryer/Coursera_deep_learning/raw/master/sequence%20model/week2/image/30.png)

![](https://github.com/cryer/Coursera_deep_learning/raw/master/sequence%20model/week2/image/31.png)

![](https://github.com/cryer/Coursera_deep_learning/raw/master/sequence%20model/week2/image/32.png)

![](https://github.com/cryer/Coursera_deep_learning/raw/master/sequence%20model/week2/image/33.png)

![](https://github.com/cryer/Coursera_deep_learning/raw/master/sequence%20model/week2/image/34.png)

![](https://github.com/cryer/Coursera_deep_learning/raw/master/sequence%20model/week2/image/35.png)

![](https://github.com/cryer/Coursera_deep_learning/raw/master/sequence%20model/week2/image/36.png)

![](https://github.com/cryer/Coursera_deep_learning/raw/master/sequence%20model/week2/image/37.png)

![](https://github.com/cryer/Coursera_deep_learning/raw/master/sequence%20model/week2/image/38.png)

![](https://github.com/cryer/Coursera_deep_learning/raw/master/sequence%20model/week2/image/39.png)

![](https://github.com/cryer/Coursera_deep_learning/raw/master/sequence%20model/week2/image/40.png)
